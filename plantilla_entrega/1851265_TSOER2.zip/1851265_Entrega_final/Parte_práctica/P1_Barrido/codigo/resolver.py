"""Reproduce P1 sin depósito. Biblioteca estándar; ejecutar: python3 resolver.py."""
import json
import math
from itertools import permutations
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent

def resolver():
    data = json.loads((BASE / 'datos/entrada.json').read_text())
    nodes = {r[0]: r[1:] for r in data['nodos']}
    qmax = data['capacidad']
    assert all(0 < r[2] <= qmax for r in nodes.values())
    angles = {i: math.degrees(math.atan2(r[1], r[0])) % 360 for i, r in nodes.items()}
    order = sorted(nodes, key=lambda i: (angles[i], i))
    groups, sweep, load = [], [], 0
    for i in order:
        tentative = load + nodes[i][2]
        if not groups or tentative > qmax:
            groups.append([])
            load = 0
        groups[-1].append(i)
        load += nodes[i][2]
        sweep.append(dict(nodo=i, angulo=angles[i], grupo=len(groups), carga=load, tentativa=tentative))
    # Redondear cada distancia a milésimas, igual que el PDF.
    def dist(a, b):
        return round(math.dist(nodes[a][:2], nodes[b][:2]) * 1000)
    def cost(route):
        return sum(dist(a, b) for a, b in zip(route, route[1:] + route[:1]))
    results = []
    for group in groups:
        route, steps = [min(group)], []
        while len(route) < len(group):
            pending = sorted(set(group) - set(route))
            minima = {j: min(dist(j, a) for a in route) for j in pending}
            chosen = min(pending, key=lambda j: (-minima[j], j))
            edges = [(a, b, dist(a, chosen) + dist(chosen, b) - dist(a, b))
                     for a, b in zip(route, route[1:] + route[:1])]
            pos = min(range(len(edges)), key=lambda p: edges[p][2])
            before = route[:]
            route.insert(pos + 1, chosen)
            steps.append(dict(antes=before, pendientes=pending, minimos=minima, elegido=chosen,
                              aristas=edges, posicion=pos, despues=route[:], costo=cost(route)))
        chains = []
        old = {frozenset((a,b)) for a,b in zip(route,route[1:]+route[:1])}
        for k, a in enumerate(route):
            for direction in (1, -1):
                b = route[(k + direction) % len(route)]
                for c in route:
                    if c in (a,b) or frozenset((b,c)) in old:
                        continue
                    d = route[(route.index(c) - direction) % len(route)]
                    g1, g2 = dist(a,b)-dist(b,c), dist(c,d)-dist(d,a)
                    chains.append(dict(t=[a,b,c,d], g1=g1, g2=g2, ganancia=g1+g2))
        # Esta instancia tiene grupos de <=4 clientes. Se certifica por enumeración;
        # las cadenas anteriores son cierres de dos aristas, NO un LK general.
        assert len(group) <= 4, 'El certificado de esta entrega está limitado a grupos de hasta 4 clientes.'
        enum = []
        for tail in permutations(sorted(set(group)-{min(group)})):
            r = [min(group)] + list(tail)
            enum.append(dict(ruta=r, costo=cost(r)))
        results.append(dict(nodos=group, carga=sum(nodes[i][2] for i in group), ruta=route,
                            costo=cost(route), pasos=steps, cadenas=chains, enumeracion=enum,
                            costo_exacto=sum(math.dist(nodes[a][:2],nodes[b][:2]) for a,b in zip(route,route[1:]+route[:1]))))
    return dict(barrido=sweep, grupos=results, total=sum(g['costo'] for g in results),
                total_exacto=sum(g['costo_exacto'] for g in results))

if __name__ == '__main__':
    r = resolver()
    (BASE/'traza.json').write_text(json.dumps(r, indent=2, ensure_ascii=False))
    for k,g in enumerate(r['grupos'],1):
        print(f"G{k}: carga={g['carga']}; ruta={g['ruta']}; longitud={g['costo']/1000:.3f}")
    print(f"Total con aristas redondeadas: {r['total']/1000:.3f}")
    print(f"Total sin redondear aristas: {r['total_exacto']:.10f}")
