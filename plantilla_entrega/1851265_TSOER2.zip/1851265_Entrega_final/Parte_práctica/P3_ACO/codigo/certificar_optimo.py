"""Enumera ciclos hamiltonianos de la matriz de entrada, sin duplicar sentidos."""
from pathlib import Path
from itertools import permutations
import json
BASE=Path(__file__).resolve().parent.parent

def certificar():
    src=json.loads((BASE/'datos/entrada.json').read_text())
    d={e:v for e,v,m in src['aristas']}
    nodes=sorted(set(''.join(d)));anchor=nodes[0]
    cycles=[]
    for tail in permutations(nodes[1:]):
        if tail[0]>tail[-1]:continue
        route=(anchor,)+tail
        length=sum(d[''.join(sorted((route[i-1],route[i])))] for i in range(len(route)))
        cycles.append({'ruta':''.join(route)+anchor,'longitud':length})
    opt=min(c['longitud'] for c in cycles)
    return {'ciclos_evaluados':len(cycles),'minimo':opt,'ciclos_minimos':[x for x in cycles if x['longitud']==opt],'ciclos':cycles}
if __name__=='__main__':print(json.dumps(certificar(),indent=2,ensure_ascii=False))
