"""Explica la tabla ACO; no inventa sorteos ni genera una corrida histórica."""
import json
from fractions import Fraction as F
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent

def resolver():
    data=json.loads((BASE/'datos/entrada.json').read_text())
    edges=data['aristas']; cities=data['ciudades']; params=data['parametros']
    dist={r[0]:r[1] for r in edges}
    def edge(a,b): return ''.join(sorted(a+b))
    def d(a,b): return dist[edge(a,b)]
    routes=[]
    for k in range(6):
        marked={r[0] for r in edges if r[2][k]}
        assert len(marked)==6 and all(sum(c in e for e in marked)==2 for c in cities)
        route=['A']
        if k==0:
            while len(route)<6:
                route.append(min((c for c in cities if c not in route),key=lambda c:(d(route[-1],c),c)))
        else:
            free=set(marked)
            while free:
                options=sorted(e for e in free if route[-1] in e)
                assert options, 'Las marcas contienen ciclos desconectados.'
                e=options[0];free.remove(e);route.append(e.replace(route[-1],''))
            assert route[-1]=='A';route.pop()
        assert len(route)==len(set(route))==6
        assert {edge(a,b) for a,b in zip(route,route[1:]+route[:1])}==marked
        routes.append(route)
    L=[sum(d(a,b) for a,b in zip(r,r[1:]+r[:1])) for r in routes]
    Q=F(str(params['Q']));rho=F(str(params['rho']));tau0=F(str(params['tau0']))
    assert tau0>0 and 0<=rho<=1
    dep={r[0]:[Q/L[k] if r[2][k] else F(0) for k in range(6)] for r in edges}
    tau={e:(1-rho)*tau0+sum(v) for e,v in dep.items()}
    weight={e:tau[e]**params['alfa']*F(1,dist[e])**params['beta'] for e in dist}
    S=[sum(weight[r[0]] for r in edges if r[2][k]) for k in range(6)]
    p={r[0]:[weight[r[0]]/S[k] if r[2][k] else F(0) for k in range(6)] for r in edges}
    transitions=[]
    for k,route in enumerate(routes):
        for step,a in enumerate(route[:-1]):
            pending=[c for c in cities if c not in route[:step+1]]
            w={b:tau0**params['alfa']*F(1,d(a,b))**params['beta'] for b in pending}
            transitions.append(dict(hormiga=k+1,paso=step+1,desde=a,pendientes=pending,
                                    elegida=route[step+1],probabilidades={b:v/sum(w.values()) for b,v in w.items()}))
    return dict(rutas=routes,L=L,depositos=dep,tau=tau,pesos=weight,S=S,p=p,transiciones=transitions,
                siguiente_A={b:weight['A'+b]/sum(weight['A'+c] for c in cities[1:]) for b in cities[1:]})

def serializar(x):
    if isinstance(x,F): return dict(fraccion=str(x),decimal=float(x))
    raise TypeError(type(x).__name__)

if __name__=='__main__':
    r=resolver()
    (BASE/'traza.json').write_text(json.dumps(r,default=serializar,indent=2,ensure_ascii=False))
    for k,(route,L) in enumerate(zip(r['rutas'],r['L']),1): print(k,' → '.join(route+route[:1]),L)
    print('Mejor longitud observada:',min(r['L']))
    print('Transición siguiente desde A:',{b:float(p) for b,p in r['siguiente_A'].items()})
