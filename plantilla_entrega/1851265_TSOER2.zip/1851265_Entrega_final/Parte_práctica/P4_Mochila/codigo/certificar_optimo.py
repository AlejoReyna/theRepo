"""Certifica el máximo por dos programaciones dinámicas independientes.
Solo biblioteca estándar. La relajación omite volumen: si su óptimo es factible,
constituye también un óptimo del problema con ambas capacidades.
"""
from pathlib import Path
from decimal import Decimal
import csv,json
BASE=Path(__file__).resolve().parent.parent

def certificar():
    par=json.loads((BASE/'datos/parametros.json').read_text())
    first=par['matricula']//100-par['matricula']//1000
    with (BASE/'datos/mochila_.csv').open() as f:
        items=[(int(r['ID']),int(Decimal(r['Peso'])*100),int(Decimal(r['Volumen'])*100),int(r['Beneficio'])) for r in csv.DictReader(f) if first<=int(r['ID'])<first+par['cantidad']]
    cap=int(Decimal(str(par['peso']))*100);vcap=int(Decimal(str(par['volumen']))*100)
    # DP por capacidad, con estado inmutable que conserva la selección 0/1.
    dp=[(0,()) for _ in range(cap+1)]
    for ident,w,v,b in items:
        for c in range(cap,w-1,-1):
            prev=dp[c-w]
            if prev[0]+b>dp[c][0]:dp[c]=(prev[0]+b,prev[1]+(ident,))
    upper,ids=dp[cap]
    # DP independiente por beneficio: peso mínimo para cada beneficio exacto.
    infinity=sum(x[1] for x in items)+1
    light=[infinity]*(sum(x[3] for x in items)+1);light[0]=0
    for ident,w,v,b in items:
        for benefit in range(len(light)-1,b-1,-1):light[benefit]=min(light[benefit],light[benefit-b]+w)
    upper2=max(i for i,w in enumerate(light) if w<=cap)
    witness=[x for x in items if x[0] in ids]
    assert len(ids)==len(set(ids))
    W=sum(x[1] for x in witness);V=sum(x[2] for x in witness);Z=sum(x[3] for x in witness)
    assert upper==upper2==Z and W<=cap and V<=vcap
    return {'beneficio_maximo':Z,'productos':list(ids),'peso':W/100,'volumen':V/100,'cota_relajacion_por_peso':upper,'cota_DP_por_beneficio':upper2,'factible_ambas_capacidades':True,'cantidad':len(ids),'alcance':'Datos originales; para otras entradas ejecutar de nuevo. Si falla la factibilidad del testigo, la relajación no certifica el problema completo.'}
if __name__=='__main__':print(json.dumps(certificar(),indent=2,ensure_ascii=False))
