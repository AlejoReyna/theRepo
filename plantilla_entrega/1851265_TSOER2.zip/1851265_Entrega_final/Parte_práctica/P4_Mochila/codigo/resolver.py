"""Mochila binaria: orden por volumen, ambas capacidades; sin garantía global."""
import csv
import json
from decimal import Decimal
from pathlib import Path

BASE=Path(__file__).resolve().parent.parent

def resolver():
    params=json.loads((BASE/'datos/parametros.json').read_text())
    start=params['matricula']//100-params['matricula']//1000
    cent=lambda x:int(Decimal(str(x))*100)
    with (BASE/'datos/mochila_.csv').open() as f:
        all_rows={int(r['ID']):(cent(r['Peso']),cent(r['Volumen']),int(r['Beneficio'])) for r in csv.DictReader(f)}
    products={i:all_rows[i] for i in range(start,start+params['cantidad'])}
    assert params['matricula']%10 in (5,6,7), 'Esta entrega implementa el criterio por volumen.'
    order=sorted(products,key=lambda i:(products[i][1],i))
    W=V=Z=0;trace=[];selected=[]
    for step,i in enumerate(order,1):
        w,v,b=products[i]
        tw,tv=W+w,V+v;accept=tw<=cent(params['peso']) and tv<=cent(params['volumen'])
        if accept: W=tw;V=tv;Z+=b;selected.append(i)
        trace.append(dict(paso=step,id=i,peso=w,volumen=v,beneficio=b,peso_tentativo=tw,
                          volumen_tentativo=tv,entra=accept,W=W,V=V,Z=Z))
    return dict(inicio=start,productos=products,orden=order,pasos=trace,seleccion=selected,W=W,V=V,Z=Z)

if __name__=='__main__':
    r=resolver()
    (BASE/'traza.json').write_text(json.dumps(r,indent=2,ensure_ascii=False))
    print('Seleccionados:',r['seleccion'])
    print(f"Peso={r['W']/100:.2f}; volumen={r['V']/100:.2f}; beneficio={r['Z']}")
